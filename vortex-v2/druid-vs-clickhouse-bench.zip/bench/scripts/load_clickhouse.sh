#!/usr/bin/env bash
# Create schema and load data/events_*.csv into ClickHouse.
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; source .env; set +a

export C=bench-clickhouse CH_USER CH_PASSWORD
CH=(docker exec -i "$C" clickhouse-client --user "$CH_USER" --password "$CH_PASSWORD")

echo "Waiting for ClickHouse..."
until "${CH[@]}" -q "SELECT 1" >/dev/null 2>&1; do sleep 2; done

"${CH[@]}" -q "DROP TABLE IF EXISTS bench.events" || true
"${CH[@]}" --multiquery < clickhouse/schema.sql

load_file() {
  docker exec -i "$C" clickhouse-client --user "$CH_USER" --password "$CH_PASSWORD" \
    --date_time_input_format best_effort \
    --query "INSERT INTO bench.events FORMAT CSV" < "$1"
}
export -f load_file

START=$(date +%s)
echo "Loading $(ls data/events_*.csv | wc -l) files, parallelism=${LOAD_PARALLEL:-4} ..."
ls data/events_*.csv | xargs -P "${LOAD_PARALLEL:-4}" -I{} bash -c 'load_file {} && echo "  loaded {}"'

if [ "${CH_OPTIMIZE:-1}" = "1" ]; then
  echo "OPTIMIZE TABLE FINAL ..."
  "${CH[@]}" -q "OPTIMIZE TABLE bench.events FINAL"
fi
echo "Load time: $(( $(date +%s) - START ))s"
"${CH[@]}" -q "SELECT count() AS rows FROM bench.events"
"${CH[@]}" -q "SELECT formatReadableSize(sum(bytes_on_disk)) AS on_disk, count() AS parts FROM system.parts WHERE database='bench' AND table='events' AND active"
