#!/usr/bin/env bash
# Full automated run across dataset scales, one engine at a time (so each gets the 4 cores alone).
#   SCALES="10000000 50000000 100000000" bash scripts/run_matrix.sh
# Extra args are passed to benchmark.py, e.g.  bash scripts/run_matrix.sh --iterations 200
set -euo pipefail
cd "$(dirname "$0")/.."
set -a; source .env; set +a
SCALES=${SCALES:-"10000000 50000000"}
ENGINES=${ENGINES:-"clickhouse druid"}
mkdir -p data results

for rows in $SCALES; do
  echo "################ dataset: $rows rows ################"
  ROWS=$rows python3 scripts/generate_data.py
  for eng in $ENGINES; do
    echo "----- $eng @ $rows rows -----"
    docker compose --profile druid --profile clickhouse down -v
    docker compose --profile "$eng" up -d
    if [ "$eng" = druid ]; then python3 scripts/load_druid.py; else bash scripts/load_clickhouse.sh; fi
    sleep 15   # let background merges / segment balancing settle
    python3 scripts/benchmark.py --engines "$eng" --label "$eng-$rows" "$@"
  done
done
docker compose --profile druid --profile clickhouse down
python3 scripts/compare.py results/*.csv
