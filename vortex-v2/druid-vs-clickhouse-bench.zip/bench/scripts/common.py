"""Shared helpers: .env loading and paths."""
import json
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
DATA_DIR = ROOT / "data"
RESULTS_DIR = ROOT / "results"


def _load_dotenv():
    p = ROOT / ".env"
    if not p.exists():
        return
    for line in p.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        os.environ.setdefault(k.strip(), v.strip().strip('"').strip("'"))


_load_dotenv()


def env(key, default=None, cast=str):
    v = os.environ.get(key)
    return cast(v) if v not in (None, "") else default


def load_meta():
    p = DATA_DIR / "meta.json"
    if not p.exists():
        raise SystemExit("data/meta.json not found - run scripts/generate_data.py first")
    return json.loads(p.read_text())
