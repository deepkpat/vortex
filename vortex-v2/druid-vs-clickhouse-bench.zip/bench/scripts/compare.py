#!/usr/bin/env python3
"""Side-by-side comparison of benchmark CSVs.

    python3 scripts/compare.py results/druid_*.csv results/clickhouse_*.csv [--out cmp.csv]
Ratio = druid / clickhouse for the same percentile (>1 means ClickHouse is faster).
If several files contain the same (engine, dataset_rows, query, scale, concurrency), the last one wins.
"""
import argparse
import csv
from collections import defaultdict


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("files", nargs="+")
    ap.add_argument("--pcts", default="p50,p95,p99")
    ap.add_argument("--out", default="")
    a = ap.parse_args()
    pcts = a.pcts.split(",")

    data = {}
    for fn in sorted(a.files):
        for r in csv.DictReader(open(fn)):
            data[(r["dataset_rows"], r["query"], r["scale"], int(r["concurrency"]), r["engine"])] = r

    keys = sorted({k[:4] for k in data}, key=lambda k: (int(k[0]), k[1], k[2], k[3]))
    header = ["rows", "query", "scale", "conc"]
    for p in pcts:
        header += [f"{p}_druid", f"{p}_ch", f"{p}_ratio"]
    header += ["qps_druid", "qps_ch"]
    rows = []
    for k in keys:
        d, c = data.get(k + ("druid",)), data.get(k + ("clickhouse",))
        row = list(k)
        for p in pcts:
            dv = float(d[p]) if d and d.get(p) else None
            cv = float(c[p]) if c and c.get(p) else None
            row += [f"{dv:.1f}" if dv is not None else "-", f"{cv:.1f}" if cv is not None else "-",
                    f"{dv / cv:.2f}x" if dv and cv else "-"]
        row += [d["qps"] if d and d.get("qps") else "-", c["qps"] if c and c.get("qps") else "-"]
        rows.append(row)

    widths = [max(len(str(x)) for x in col) for col in zip(header, *rows)]
    for r in [header] + rows:
        print("  ".join(str(x).rjust(w) for x, w in zip(r, widths)))
    if a.out:
        with open(a.out, "w", newline="") as f:
            w = csv.writer(f)
            w.writerow(header)
            w.writerows(rows)
        print(f"\nwritten {a.out}")


if __name__ == "__main__":
    main()
