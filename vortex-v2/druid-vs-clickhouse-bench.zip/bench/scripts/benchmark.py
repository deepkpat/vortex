#!/usr/bin/env python3
"""Query benchmark for Druid / ClickHouse.

Dimensions of the test matrix (all configurable):
  * query          - queries/queries.json (filter with --queries regex)
  * time-range scale - --scales 6h,1d,7d,all   (how much data each query touches)
  * concurrency    - --concurrency 1,4,16      (parallel clients)
  * percentiles    - --percentiles 50,90,95,99,99.9

Every (scale, iteration) uses the SAME random time window for both engines (seeded), so
runs are comparable. Results are appended to a CSV; use compare.py to view side by side.

Examples:
  python3 scripts/benchmark.py --engines clickhouse
  python3 scripts/benchmark.py --engines druid --scales 1d,all --concurrency 1,8 --iterations 200
"""
import argparse
import csv
import json
import random
import re
import sys
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from datetime import datetime, timedelta

import numpy as np
import requests
from requests.adapters import HTTPAdapter

from common import ROOT, RESULTS_DIR, env, load_meta

FMT = "%Y-%m-%d %H:%M:%S"


# ------------------------------------------------------------------ engines
class Druid:
    name = "druid"
    ts_col = "__time"
    time_pred = "__time >= TIMESTAMP '{t0}' AND __time < TIMESTAMP '{t1}'"

    def __init__(self, timeout):
        self.url = env("DRUID_ROUTER_URL", "http://localhost:8888") + "/druid/v2/sql"
        self.health = env("DRUID_ROUTER_URL", "http://localhost:8888") + "/status/health"
        self.timeout = timeout

    def ping(self):
        return requests.get(self.health, timeout=5).json() is True

    def run(self, sess, sql):
        r = sess.post(self.url, json={
            "query": sql, "resultFormat": "array",
            "context": {"useCache": False, "populateCache": False, "useResultLevelCache": False,
                        "populateResultLevelCache": False, "timeout": int(self.timeout * 1000)}},
            timeout=self.timeout)
        if r.status_code != 200:
            raise RuntimeError(f"HTTP {r.status_code}: {r.text[:300]}")
        return r.json()

    def count(self, sess):
        return self.run(sess, "SELECT COUNT(*) FROM events")[0][0]


class ClickHouse:
    name = "clickhouse"
    ts_col = "ts"
    time_pred = "ts >= toDateTime64('{t0}', 3, 'UTC') AND ts < toDateTime64('{t1}', 3, 'UTC')"

    def __init__(self, timeout):
        self.base = env("CH_URL", "http://localhost:8123")
        self.auth = (env("CH_USER", "bench"), env("CH_PASSWORD", "bench"))
        self.timeout = timeout

    def ping(self):
        return requests.get(self.base + "/ping", timeout=5).text.strip() == "Ok."

    def run(self, sess, sql):
        r = sess.post(self.base, params={"database": "bench", "max_execution_time": int(self.timeout)},
                      data=(sql + " FORMAT JSONCompact").encode(), auth=self.auth, timeout=self.timeout)
        if r.status_code != 200:
            raise RuntimeError(f"HTTP {r.status_code}: {r.text[:300]}")
        return r.json()["data"]

    def count(self, sess):
        return int(self.run(sess, "SELECT count() FROM events")[0][0])


ENGINES = {"druid": Druid, "clickhouse": ClickHouse}


# ------------------------------------------------------------------ helpers
def parse_scale(s, total_hours):
    if s == "all":
        return total_hours
    m = re.fullmatch(r"(\d+)([hd])", s)
    if not m:
        raise SystemExit(f"bad scale '{s}' (use e.g. 6h, 1d, 7d, all)")
    return int(m[1]) * (24 if m[2] == "d" else 1)


def make_windows(scale, hours, total_hours, start, count, seed):
    rng = random.Random(f"{seed}:{scale}")
    out = []
    for _ in range(count):
        off = rng.randint(0, total_hours - hours) if hours < total_hours else 0
        t0 = start + timedelta(hours=off)
        out.append((t0.strftime(FMT), (t0 + timedelta(hours=hours)).strftime(FMT)))
    return out


def render(engine, q, w):
    sql = q.get(engine.name) or q["sql"]
    return (sql.replace("{TIME}", engine.time_pred.format(t0=w[0], t1=w[1]))
               .replace("{TS}", engine.ts_col))


_tls = threading.local()


def session_for(conc):
    if not hasattr(_tls, "s"):
        s = requests.Session()
        s.mount("http://", HTTPAdapter(pool_connections=conc, pool_maxsize=conc))
        _tls.s = s
    return _tls.s


def bench_combo(engine, q, sqls, warmup, conc):
    def one(sql):
        t = time.perf_counter()
        try:
            engine.run(session_for(conc), sql)
            return (time.perf_counter() - t) * 1000.0, None
        except Exception as e:  # noqa
            return None, str(e)

    for sql in sqls[:warmup]:
        _, err = one(sql)
        if err:
            return [], len(sqls) - warmup, 0.0, err
    measured = sqls[warmup:]
    t0 = time.perf_counter()
    with ThreadPoolExecutor(max_workers=conc) as ex:
        res = list(ex.map(one, measured))
    wall = time.perf_counter() - t0
    lats = [r[0] for r in res if r[0] is not None]
    errs = [r[1] for r in res if r[1]]
    return lats, len(errs), wall, (errs[0] if errs else None)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--engines", default="druid,clickhouse")
    ap.add_argument("--scales", default="6h,1d,7d,all")
    ap.add_argument("--concurrency", default="1,4,16")
    ap.add_argument("--percentiles", default="50,90,95,99")
    ap.add_argument("--iterations", type=int, default=100, help="measured runs per (query,scale,concurrency)")
    ap.add_argument("--warmup", type=int, default=5)
    ap.add_argument("--queries", default=".*", help="regex on query name")
    ap.add_argument("--queries-file", default=str(ROOT / "queries" / "queries.json"))
    ap.add_argument("--timeout", type=float, default=300)
    ap.add_argument("--seed", type=int, default=1)
    ap.add_argument("--label", default="")
    ap.add_argument("--out", default="")
    a = ap.parse_args()

    meta = load_meta()
    start = datetime.strptime(meta["start"], FMT)
    total_hours = meta["days"] * 24
    pcts = [float(p) for p in a.percentiles.split(",")]
    pcols = [f"p{p:g}" for p in pcts]
    queries = [q for q in json.load(open(a.queries_file)) if re.search(a.queries, q["name"])]
    concs = [int(c) for c in a.concurrency.split(",")]

    scales = []
    for s in a.scales.split(","):
        h = parse_scale(s.strip(), total_hours)
        if h >= total_hours and s.strip() != "all":
            print(f"skip scale {s}: >= dataset span ({meta['days']}d), use 'all'")
            continue
        scales.append((s.strip(), h))

    if a.iterations < 100 and any(p > 99 for p in pcts):
        print("WARNING: p99.9 needs >=1000 iterations to be meaningful; p99 needs >=100")

    RESULTS_DIR.mkdir(exist_ok=True)
    fields = ["ts", "engine", "label", "dataset_rows", "query", "category", "scale", "concurrency",
              "iterations", "errors", "min", "mean", *pcols, "max", "qps"]

    for ename in a.engines.split(","):
        eng = ENGINES[ename.strip()](a.timeout)
        try:
            ok = eng.ping()
        except Exception as e:  # noqa
            ok = False
        if not ok:
            print(f"[{ename}] not reachable - is it up? skipping")
            continue
        n = eng.count(requests.Session())
        print(f"\n===== {eng.name}: {n:,} rows in engine (dataset meta: {meta['rows']:,}) =====")
        if n != meta["rows"]:
            print("WARNING: row count differs from data/meta.json - did the load finish?")

        out = a.out or str(RESULTS_DIR / f"{eng.name}_{meta['rows']}_{time.strftime('%Y%m%d-%H%M%S')}.csv")
        new = True
        with open(out, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=fields)
            w.writeheader()
            print(f"{'query':22} {'scale':>5} {'conc':>4} {'err':>3} " + " ".join(f"{c:>9}" for c in ['mean'] + pcols) + f" {'qps':>8}")
            for q in queries:
                for sname, hours in scales:
                    windows = make_windows(sname, hours, total_hours, start, a.warmup + a.iterations, a.seed)
                    sqls = [render(eng, q, win) for win in windows]
                    for c in concs:
                        lats, nerr, wall, err = bench_combo(eng, q, sqls, a.warmup, c)
                        row = {"ts": int(time.time()), "engine": eng.name, "label": a.label,
                               "dataset_rows": meta["rows"], "query": q["name"], "category": q["category"],
                               "scale": sname, "concurrency": c, "iterations": a.iterations, "errors": nerr}
                        if lats:
                            arr = np.array(lats)
                            row.update({"min": arr.min(), "mean": arr.mean(), "max": arr.max(),
                                        "qps": len(arr) / wall if wall else 0})
                            for p, col in zip(pcts, pcols):
                                row[col] = np.percentile(arr, p)
                        w.writerow({k: (f"{v:.2f}" if isinstance(v, float) else v) for k, v in row.items()})
                        f.flush()
                        vals = " ".join(f"{row.get(k, float('nan')):9.1f}" for k in ["mean"] + pcols)
                        print(f"{q['name']:22} {sname:>5} {c:>4} {nerr:>3} {vals} {row.get('qps', 0):8.1f}")
                        if err:
                            print(f"    first error: {err}")
        print(f"\nResults (latencies in ms) -> {out}")


if __name__ == "__main__":
    main()
