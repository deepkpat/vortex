#!/usr/bin/env python3
"""Submit a native batch (index_parallel) ingestion for data/events_*.csv into Druid
and wait until the segments are loaded and queryable."""
import json
import sys
import time

import requests

from common import env, load_meta

ROUTER = env("DRUID_ROUTER_URL", "http://localhost:8888")
PARALLELISM = env("DRUID_INGEST_PARALLELISM", 2, int)
DATASOURCE = "events"


def wait_for(desc, fn, timeout=600, every=3):
    t0 = time.time()
    while time.time() - t0 < timeout:
        try:
            if fn():
                return
        except requests.RequestException:
            pass
        time.sleep(every)
    sys.exit(f"Timed out waiting for {desc}")


def spec(meta):
    dims = [{"type": "long", "name": "user_id"}, "country", "device", "event_type", "campaign_id", "page",
            {"type": "double", "name": "revenue"}, {"type": "long", "name": "duration_ms"}]
    return {
        "type": "index_parallel",
        "spec": {
            "ioConfig": {
                "type": "index_parallel",
                "inputSource": {"type": "local", "baseDir": "/data", "filter": "events_*.csv"},
                "inputFormat": {"type": "csv", "columns": meta["columns"], "findColumnsFromHeader": False},
                "appendToExisting": False,
            },
            "dataSchema": {
                "dataSource": DATASOURCE,
                "timestampSpec": {"column": "ts", "format": "iso"},
                "dimensionsSpec": {"dimensions": dims},
                # rollup=false so Druid stores the same raw rows as ClickHouse (fair comparison).
                # Enable rollup + metricsSpec if your production datasource does.
                "granularitySpec": {"segmentGranularity": "day", "queryGranularity": "none", "rollup": False},
            },
            "tuningConfig": {
                "type": "index_parallel",
                "partitionsSpec": {"type": "dynamic", "maxRowsPerSegment": 5_000_000},
                "maxRowsInMemory": 1_000_000,
                "maxNumConcurrentSubTasks": PARALLELISM,
            },
        },
    }


def main():
    meta = load_meta()
    print("Waiting for Druid router / overlord / workers ...")
    wait_for("router", lambda: requests.get(f"{ROUTER}/status/health", timeout=5).json() is True)
    wait_for("middleManager", lambda: len(requests.get(f"{ROUTER}/druid/indexer/v1/workers", timeout=5).json()) > 0)

    r = requests.post(f"{ROUTER}/druid/indexer/v1/task", json=spec(meta), timeout=30)
    r.raise_for_status()
    task = r.json()["task"]
    print(f"Submitted task {task}")

    t0 = time.time()
    while True:
        st = requests.get(f"{ROUTER}/druid/indexer/v1/task/{task}/status", timeout=10).json()["status"]
        state = st["status"]
        print(f"  [{time.time() - t0:5.0f}s] {state}", flush=True)
        if state == "SUCCESS":
            break
        if state == "FAILED":
            sys.exit(f"Ingestion failed: {st}\nLogs: {ROUTER}/druid/indexer/v1/task/{task}/log")
        time.sleep(10)
    print(f"Ingestion time: {time.time() - t0:.0f}s")

    print("Waiting for historical to load all segments ...")
    wait_for("segment load", lambda: requests.get(f"{ROUTER}/druid/coordinator/v1/loadstatus", timeout=10)
             .json().get(DATASOURCE, 0) >= 100.0, timeout=1800, every=5)

    q = requests.post(f"{ROUTER}/druid/v2/sql", json={"query": "SELECT COUNT(*) AS c FROM events"}, timeout=120).json()
    print(f"Rows in Druid: {q[0]['c']:,} (expected {meta['rows']:,})")


if __name__ == "__main__":
    main()
