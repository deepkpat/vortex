#!/usr/bin/env python3
"""Generate synthetic event data: one header-less CSV per day in ./data.

Scale is controlled via .env / env vars / CLI flags, e.g.:
    ROWS=100000000 DAYS=90 python3 scripts/generate_data.py
    python3 scripts/generate_data.py --rows 1000000 --days 7
"""
import argparse
import json
import time
from datetime import date, datetime, timedelta, timezone

import numpy as np
import pandas as pd

from common import DATA_DIR, env

COLUMNS = ["ts", "user_id", "country", "device", "event_type", "campaign_id",
           "page", "revenue", "duration_ms"]

COUNTRIES = ("US IN GB DE FR BR CA AU JP CN ES IT MX NL SE NO DK FI PL TR RU KR ID PH VN TH MY SG AE SA "
             "ZA NG EG AR CL CO PE UA RO CZ PT GR HU IE NZ IL CH AT BE PK").split()
DEVICES = ["mobile", "desktop", "tablet", "tv", "console", "bot"]
EVENT_TYPES = ["view", "click", "search", "add_to_cart", "purchase", "login", "logout", "signup",
               "share", "like", "comment", "scroll", "play", "pause", "download", "error",
               "refund", "subscribe", "unsubscribe", "impression"]
PAGE_WORDS = ["home", "product", "category", "cart", "checkout", "search", "blog", "account", "help", "landing"]


def zipf_weights(n, s):
    w = 1.0 / np.power(np.arange(1, n + 1), s)
    return w / w.sum()


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--rows", type=int, default=env("ROWS", 10_000_000, int))
    ap.add_argument("--days", type=int, default=env("DAYS", 30, int))
    ap.add_argument("--start-date", default=env("START_DATE", "2025-01-01"))
    ap.add_argument("--users", type=int, default=env("USERS", 1_000_000, int), help="user_id cardinality")
    ap.add_argument("--campaigns", type=int, default=env("CAMPAIGNS", 1000, int))
    ap.add_argument("--pages", type=int, default=env("PAGES", 10_000, int))
    ap.add_argument("--seed", type=int, default=env("SEED", 42, int))
    ap.add_argument("--chunk-rows", type=int, default=env("CHUNK_ROWS", 1_000_000, int))
    a = ap.parse_args()

    DATA_DIR.mkdir(exist_ok=True)
    for old in DATA_DIR.glob("events_*.csv"):
        old.unlink()

    rng = np.random.default_rng(a.seed)
    start = date.fromisoformat(a.start_date)
    countries, devices, etypes = map(np.array, (COUNTRIES, DEVICES, EVENT_TYPES))
    campaigns = np.array([f"cmp_{i:05d}" for i in range(a.campaigns)])
    pages = np.array([f"/{PAGE_WORDS[i % len(PAGE_WORDS)]}/{i}/" for i in range(a.pages)])
    w_country, w_device = zipf_weights(len(countries), 1.0), zipf_weights(len(devices), 1.2)
    w_event, w_camp, w_page = (zipf_weights(len(etypes), 1.1), zipf_weights(a.campaigns, 0.8),
                               zipf_weights(a.pages, 0.7))
    purchase_idx = EVENT_TYPES.index("purchase")

    per_day, extra = divmod(a.rows, a.days)
    t0, written = time.time(), 0
    for d in range(a.days):
        n_day = per_day + (1 if d < extra else 0)
        if n_day == 0:
            continue
        day = start + timedelta(days=d)
        base_ms = int(datetime(day.year, day.month, day.day, tzinfo=timezone.utc).timestamp() * 1000)
        path = DATA_DIR / f"events_{day:%Y-%m-%d}.csv"
        with open(path, "w") as f:
            done = 0
            while done < n_day:
                n = min(a.chunk_rows, n_day - done)
                ts = np.sort(base_ms + rng.integers(0, 86_400_000, n)).astype("datetime64[ms]").astype(str)
                ev = rng.choice(len(etypes), n, p=w_event)
                revenue = np.where(ev == purchase_idx, np.round(rng.lognormal(3.0, 1.0, n), 2), 0.0)
                df = pd.DataFrame({
                    "ts": ts,
                    "user_id": (a.users * rng.random(n) ** 2).astype(np.int64),  # skewed
                    "country": countries[rng.choice(len(countries), n, p=w_country)],
                    "device": devices[rng.choice(len(devices), n, p=w_device)],
                    "event_type": etypes[ev],
                    "campaign_id": campaigns[rng.choice(a.campaigns, n, p=w_camp)],
                    "page": pages[rng.choice(a.pages, n, p=w_page)],
                    "revenue": revenue,
                    "duration_ms": rng.gamma(2.0, 150.0, n).astype(np.int64),
                })
                df[COLUMNS].to_csv(f, header=False, index=False, float_format="%.2f")
                done += n
        written += n_day
        el = time.time() - t0
        print(f"[{d + 1}/{a.days}] {path.name}: {n_day:,} rows | total {written:,} | {written / el:,.0f} rows/s", flush=True)

    end = start + timedelta(days=a.days)
    meta = {"rows": written, "days": a.days, "columns": COLUMNS,
            "start": f"{start} 00:00:00", "end": f"{end} 00:00:00",
            "users": a.users, "campaigns": a.campaigns, "pages": a.pages, "seed": a.seed}
    (DATA_DIR / "meta.json").write_text(json.dumps(meta, indent=2))
    print(f"Done: {written:,} rows in {time.time() - t0:.0f}s -> {DATA_DIR}")


if __name__ == "__main__":
    main()
