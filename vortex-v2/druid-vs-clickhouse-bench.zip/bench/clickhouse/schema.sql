CREATE DATABASE IF NOT EXISTS bench;

-- Sort key mirrors Druid's layout: time first, then the commonly filtered dimensions.
-- Tweak freely; it's the single biggest performance lever in ClickHouse.
CREATE TABLE IF NOT EXISTS bench.events
(
    ts          DateTime64(3, 'UTC'),
    user_id     UInt64,
    country     LowCardinality(String),
    device      LowCardinality(String),
    event_type  LowCardinality(String),
    campaign_id LowCardinality(String),
    page        String,
    revenue     Float64,
    duration_ms UInt32
)
ENGINE = MergeTree
PARTITION BY toYYYYMMDD(ts)
ORDER BY (toStartOfHour(ts), country, event_type, user_id);
